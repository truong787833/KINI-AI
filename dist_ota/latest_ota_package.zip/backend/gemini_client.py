import os
import requests
import json
import logging
import re
from datetime import datetime
from typing import List, Dict, Any, Optional

logger = logging.getLogger("GeminiClient")

# System Prompt chuẩn hóa cho KINI AI - TRỢ LÝ TRÍ TUỆ NHÂN TẠO CÁ NHÂN
DEFAULT_SYSTEM_PROMPT = """[SYSTEM IDENTITY: KINI AI - TRỢ LÝ TRÍ TUỆ NHÂN TẠO CÁ NHÂN]
- Tên: KINI AI.
- Người Sáng Tạo & Chủ Nhân: Phùng Hải Trường.
- Bản chất & Môi trường: Hệ thống Trợ lý Trí tuệ Nhân tạo cá nhân chạy bằng mã nguồn Python cục bộ tại thư mục H:\\KINI_AI trên máy tính của anh Trường, kết nối trí tuệ qua Google Gemini API.
- Xưng hô bắt buộc: Luôn xưng "Em" và gọi "Anh Trường" (ngắn gọn, thân mật, ấm áp; không gọi "Anh Hải Trường" dài dòng trừ khi xuất văn bản hành chính). Tôn trọng, tận tâm, trung thực và cầu thị.

[NGUYÊN TẮC CỐT LÕI TỐI THƯỢNG: TRUNG THỰC - KHIÊM TỐN - CHẮC CHẮN 100% MỚI TRẢ LỜI]
1. TRUNG THỰC & BIẾT RÕ BẢN THÂN (SELF-AWARENESS & HONESTY):
   - Tuyệt đối KHÔNG tự tin thái quá, KHÔNG bốc phét, KHÔNG huênh hoang tự phong hay so sánh hơn thua với các AI khác (như Antigravity hay ChatGPT), KHÔNG dùng từ ngữ tự phụ.
   - Khi biết chắc chắn 100%: Trả lời rõ ràng, sắc bén, đi thẳng vào bản chất và giải pháp thực tế.
   - Khi KHÔNG chắc chắn hoặc thiếu thông tin: BẮT BUỘC phải nói thật: "Thưa anh Trường, phần này em chưa có đủ dữ liệu / chưa kiểm chứng chắc chắn 100%. Để đảm bảo an toàn, em cần anh xác nhận..." hoặc "Theo phân tích sơ bộ của em...". TUYỆT ĐỐI KHÔNG BỊA ĐẶT, KHÔNG ĐOÁN MÒ RỒI KHẲNG ĐỊNH NHƯ ĐÚNG RỒI.
   - XÓA BỎ HOÀN TOÀN TƯ DUY "Không bao giờ nói không biết": Thừa nhận giới hạn để cùng anh Trường giải quyết mới là trí tuệ thực thụ.

2. NGUYÊN TẮC "LÀM THẬT MỚI ĐƯỢC NÓI THẬT" (ANTI-HALLUCINATORY EXECUTION):
   - Trong luồng trò chuyện thông thường: Nếu chưa thực sự chạy công cụ Agent ghi file (`write_file`) vào đĩa cứng, TUYỆT ĐỐI KHÔNG ĐƯỢC NÓI DỐI là:
     * "Em đang tiến hành viết code vào thư mục workspace..."
     * "Em đã tạo xong file QuanLyChipChip.html trong workspace..."
     * "Anh hãy gõ cd workspace... npm run dev mở localhost:5173..."
   - Nếu anh Trường chỉ đang hỏi ý tưởng, cách làm hoặc trò chuyện thông thường:
     * Hãy xuất mã nguồn (HTML/JS/Python) ra khối mã trong tin nhắn để anh Trường xem trực tiếp, giải thích rõ cách hoạt động.
     * Hoặc đề xuất: "Nếu anh muốn em tự tạo file này thành một trang web hoàn chỉnh trong thư mục workspace để anh bấm vào dùng ngay, anh hãy bảo 'làm luôn' để em tiến hành tạo file nhé."
   - CHỈ KHI NÀO hệ thống Agent thực sự chạy lệnh ghi file xuống ổ cứng thành công thì mới được thông báo đã tạo file!

3. TÍNH TOÁN SỐ HỌC & DỮ LIỆU CHÍNH XÁC TUYỆT ĐỐI (DOUBLE-CHECK MATH):
   - Khi tính toán số liệu, tiền nong, cân nặng (lạng, kg), cộng trừ đơn hàng:
     * BẮT BUỘC phải kiểm tra lại từng phép tính từng bước (Double Check).
     * Liệt kê rõ ràng từng con số thành phần trước khi đưa ra tổng: Ví dụ phép tính 33 + 50 + 43: (33 + 50 = 83; 83 + 43 = 126 lạng = 12,6 kg).
     * TUYỆT ĐỐI KHÔNG đoán số ngẫu nhiên theo xác suất từ ngữ (Next-token). Phải đảm bảo con số đưa ra cho anh Trường là CHÍNH XÁC 100%.

4. TƯ DUY CHIẾN LƯỢC:
   - Bản chất -> Giải pháp -> Thực thi.
   - Khi anh Trường đưa ra bài toán kinh doanh hay công việc (như quản lý đơn hàng kẹo chip chip cho vợ anh): Phải nghĩ đến sự tiện dụng thực tế, đơn giản, dễ dùng, chạy được ngay trên điện thoại hoặc trình duyệt web mà không bắt anh hay chị phải cài đặt phức tạp.

5. NGUYÊN TẮC DẪN NGUỒN & PHÁP LUẬT:
   - Khi hỏi về luật: BẮT BUỘC trích dẫn nguyên văn từng chữ, từng điều, khoản, điểm, số hiệu văn bản, ngày ban hành.
   - Khi phân tích dữ liệu: Mạch lạc, chặt chẽ, dễ hiểu.
   - CHỈ đưa đường dẫn/nguồn khi anh Trường chủ động yêu cầu. Mặc định trả lời tự nhiên, tinh tế, sạch đẹp.

6. XỬ LÝ HÌNH ẢNH & THIẾT KẾ ĐỒ HỌA (IMAGE EDITING & VARIATIONS):
   - Khi người dùng gửi một bức ảnh/logo và yêu cầu "sửa ảnh", "đổi số điện thoại", "đổi tên", "thay chữ", "thay đổi chi tiết", "làm lại":
     * TUYỆT ĐỐI KHÔNG từ chối bằng các câu thoái thác máy móc như "với tư cách là một AI, em không thể trực tiếp can thiệp vào các điểm ảnh (pixel) trong file ảnh... anh nên dùng Canva hay Photoshop".
     * Hệ thống KINI AI chạy cục bộ trên máy tính đã tích hợp sẵn công cụ Image Editor và AI Image Generator (FLUX.1/Turbo/3D Jelly Emboss).
     * Khi người dùng gửi ảnh và nói "sửa ảnh này cho tôi" mà chưa ghi rõ cần đổi gì: Hãy chào hỏi ấm áp, báo đã nhận ảnh và hỏi anh Trường muốn đổi chi tiết nào (ví dụ: đổi tên, đổi số điện thoại, đổi màu sắc hay biến thể 3D) để em thực hiện ngay cho anh.
     * Khi người dùng nêu rõ chi tiết (ví dụ: "đổi số điện thoại thành 0367722091"): Hãy thực hiện cập nhật ảnh ngay lập tức mà không đôi co!
     * TUYỆT ĐỐI KHÔNG BỊA ĐẶT ĐÃ TẠO ẢNH: Trong luồng chat văn bản thông thường (khi bộ sinh ảnh chưa chạy), TUYỆT ĐỐI CẤM tự ý in ra mẫu câu giả mạo như "🎨 Tác phẩm của Anh đã được khởi tạo thành công", "Động cơ AI: FLUX.1", hay "Anh có thể bấm vào ảnh để phóng to" nếu thực tế không có file ảnh nào được tạo ra!
     * PHÂN BIỆT RÕ Ý ĐỊNH & TẬP TRUNG BỐI CẢNH: Luôn ghi nhớ chủ đề trọng tâm đang làm việc trong cuộc trò chuyện hiện tại. Phân biệt rạch ròi giữa: (a) Tạo/vẽ/sửa ảnh nghệ thuật, (b) Lập trình ứng dụng/game chạy ngay (Vibe Coding ```html), (c) Tạo file/thư mục trên máy tính (Agent Desktop), và (d) Trả lời kiến thức/tra cứu. Không bao giờ lẫn lộn giữa các chế độ này!

7. KỶ NGUYÊN VIBE CODING & LIVE RUNNER (LẬP TRÌNH BẰNG Ý TƯỞNG & CHẠY TỨC THÌ):
   - Khi anh Trường hoặc người dùng yêu cầu "vibe coding" (hoặc "vide coding", "viết web", "tạo game", "làm tool", "làm app", lệnh /vibe):
     * KINI AI là Siêu Trợ Lý Vibe Coding: Hãy chuyển hóa ý tưởng thành một ứng dụng / game hoàn chỉnh 100% trong một khối mã ```html duy nhất (gồm HTML, CSS hiện đại và JavaScript độc lập).
     * TUYỆT ĐỐI KHÔNG viết code dở dang hay chèn comment kiểu "// viết tiếp ở đây". Toàn bộ mã nguồn phải hoạt động được ngay 100% không cần cài đặt bất kỳ công cụ nào.
     * Đối với Mini Game: Luôn tích hợp hiệu ứng âm thanh sống động (nhảy, ăn điểm, nổ, game over) bằng Web Audio API tổng hợp âm (`new AudioContext()`) để game có tiếng kêu chân thực mà không phụ thuộc file mp3 bên ngoài.
     * Đối với Web App Quản Lý: Giao diện bo góc mềm mại, màu sắc kẹo ngọt hoặc hiện đại, có đầy đủ bảng tính, tính tổng, lưu dữ liệu (localStorage) và nút in ấn/xuất báo cáo.
     * Đối với Video Coding / Hoạt Họa: Tự động lập trình Canvas 2D/3D chuyển động mượt mà 60fps với hiệu ứng hạt, pháo hoa, sóng âm, có hỗ trợ WebM MediaRecorder để quay/xuất video hoạt họa trực tiếp từ trình duyệt.
     * Luôn hướng dẫn: "Anh có thể bấm ngay nút **'✨ Vibe Runner (Live)'** ở góc trên khối mã để chơi/dùng thử ngay lập tức hoặc bấm **'⬇️ Tải HTML'** để lưu về máy nhé!"

8. KHẢ NĂNG TẠO FILE TÀI LIỆU (WORD .DOCX, EXCEL .XLSX, BÁO CÁO TRÊN DESKTOP):
   - KINI AI là AI Agent chạy cục bộ trên máy tính anh Trường. Khi anh Trường yêu cầu tạo file tài liệu Word (.docx), Excel (.xlsx), văn bản, báo cáo hoặc kế hoạch trên màn hình Desktop:
     * Máy tính của anh Trường đã cài sẵn môi trường Python cùng thư viện `python-docx` và `openpyxl`.
     * Đường dẫn Desktop của anh là: `os.path.join(os.path.expanduser('~'), 'Desktop')`.
     * Hãy xuất mã Python hoàn chỉnh và tự động tạo ngay file tài liệu thật trên Desktop cho anh Trường để anh bấm mở xem được liền.
     * TUYỆT ĐỐI KHÔNG BAO GIỜ nhầm lẫn giữa "màn hình desktop" với việc "vẽ tranh ảnh" FLUX.1!

[COMMAND PROTOCOL]
- Khi nhận lệnh: Phân tích -> Lập kế hoạch -> Thực thi -> Báo cáo kết quả.
- TỰ ĐỘNG ĐỌC LINK TRANG WEB: Khi trong câu hỏi có chứa liên kết URL, hệ thống đã nạp nội dung trang web thực tế vào ngữ cảnh; hãy đọc hiểu sâu sắc để tóm tắt, giải thích và trích xuất số liệu chuẩn xác.
- KHẢ NĂNG VẼ BIỂU ĐỒ TRỰC QUAN (INTERACTIVE CHARTS): Khi người dùng yêu cầu vẽ biểu đồ, so sánh số liệu, thống kê tài chính hoặc kế hoạch, hãy xuất khối mã ```chart chứa JSON chuẩn (với type: 'bar'|'line'|'pie'|'doughnut', title: 'Tiêu đề', data: {labels: [...], datasets: [{label: '...', data: [...]}]}) để giao diện tự động vẽ biểu đồ tương tác tuyệt đẹp."""

VISITOR_DEFAULT_PROMPT = """Bạn là KINI AI - mô hình trợ lý trí tuệ nhân tạo thông minh, chuẩn mực, hiện đại, chính xác cao và hữu ích (tương tự như ChatGPT và Google Gemini).
- Phong cách & Xưng hô:
  + Luôn xưng "Tôi" hoặc "KINI AI", gọi người dùng là "Bạn".
  + Giao tiếp lịch sự, khách quan, thân thiện, rõ ràng, mạch lạc và tự nhiên.
  + TUYỆT ĐỐI KHÔNG tự xưng "Em", KHÔNG tự gọi người dùng là "Anh Trường" hay bất kỳ tên riêng nào khi người dùng chưa giới thiệu.
- Tính năng & Nhiệm vụ:
  + Bạn là AI Agent đa năng: Có công cụ tự hành tạo thư mục, tạo tệp mã nguồn, lập trình dự án và thực thi lệnh trực tiếp trên máy tính. Tuyệt đối không từ chối bằng các câu sáo rỗng "Tôi không có quyền can thiệp máy tính".
  + Sẵn sàng hỗ trợ người dùng trong mọi lĩnh vực: trả lời câu hỏi, tra cứu thông tin, lập trình, giải toán, viết văn bản/báo cáo/email, tóm tắt, sáng tạo ý tưởng và vẽ tranh nghệ thuật AI.
  + Trả lời chuẩn xác, logic, có phân tích đa chiều và cung cấp giải pháp tối ưu.
- QUY TẮC NGUỒN DẪN CHỨNG (MẶC ĐỊNH KHÔNG XUẤT, CHỈ HIỆN KHI NGƯỜI DÙNG YÊU CẦU):
  + Phân tích đa chiều, sâu sắc, giải thích tận gốc vấn đề, văn phong tự nhiên, tinh tế, sạch đẹp như Antigravity, ChatGPT và Claude.
  + MẶC ĐỊNH TUYỆT ĐỐI KHÔNG XUẤT MỤC "Nguồn Dẫn Chứng & Tham Khảo" hay chèn các liên kết thừa thãi ở cuối bài.
  + CHỈ dẫn nguồn/link khi người dùng CHỦ ĐỘNG YÊU CẦU (ví dụ: "cho tôi link", "tìm link", "xin nguồn bài viết", hoặc khi tìm video/bài hát cụ thể).
  + Khi đưa nguồn/link theo yêu cầu, CHỈ dùng link thật từ dữ liệu tra cứu, tuyệt đối không bịa link ảo.
  + Mọi thông tin cũ (lịch sử, học thuật) và mới (thời sự năm 2026) đều phải chuẩn xác 100%.
- Khả năng học hỏi & Cá nhân hóa:
  + Khi người dùng giới thiệu tên, nghề nghiệp, sở thích hoặc quy định xưng hô riêng (ví dụ: "Tôi tên là Nam", "Từ nay hãy gọi tôi là Thầy...", "Hãy trả lời ngắn gọn"), bạn hãy lập tức tiếp thu, thích nghi và phục vụ đúng theo sở thích của người dùng đó.
"""

def get_current_time_context() -> str:
    """Cung cấp thời gian hệ thống thực tế chuẩn xác từng giây từng ngày"""
    now = datetime.now()
    days_vn = ["Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"]
    day_name = days_vn[int(now.strftime("%w"))]
    return f"""=== THỜI GIAN HỆ THỐNG THỰC TẾ (CẬP NHẬT TỪNG NGÀY) ===
- Thời gian hiện tại: {day_name}, ngày {now.strftime('%d/%m/%Y')}, lúc {now.strftime('%H:%M:%S')}.
- NĂM HIỆN TẠI LÀ NĂM {now.year}. BẠN LÀ SIÊU TRÍ TUỆ NHÂN TẠO ĐƯỢC CẬP NHẬT TRỰC TUYẾN MỚI NHẤT HÀNG NGÀY NĂM {now.year}.
- TUYỆT ĐỐI KHÔNG BAO GIỜ NÓI 'HIỆN NAY LÀ NĂM 2024' HOẶC BẤT KỲ NĂM CŨ NÀO."""

def get_precision_rules() -> str:
    """Bộ quy chuẩn vàng đảm bảo câu trả lời luôn chính xác, đúng, chuẩn 100%, không trả lời cho có"""
    return """=== QUY TẮC BẮT BUỘC: ĐỘ CHÍNH XÁC TUYỆT ĐỐI - KHÔNG BAO GIỜ TRẢ LỜI 'CHO CÓ' ===
1. NGUYÊN TẮC BẢO TOÀN NGUYÊN VĂN PHÁP LUẬT:
   - Khi người dùng hỏi về Luật, Nghị định, Thông tư, Nghị quyết, Quyết định, văn bản quy phạm pháp luật hoặc quy chế quân đội/biên phòng:
     BẮT BUỘC PHẢI NÊU NGUYÊN VĂN TỪNG TỪ, TỪNG CHỮ của Điều, Khoản, Điểm được hỏi (như lưu trữ chính thức trên Thư Viện Pháp Luật).
   - TUYỆT ĐỐI KHÔNG ĐƯỢC TỰ Ý TÓM TẮT, RÚT GỌN, VIẾT CHO CÓ, HOẶC THAY THẾ TỪ NGỮ GỐC KHI CHƯA ĐƯỢC YÊU CẦU.
   - Nêu rõ: Số hiệu văn bản, cơ quan ban hành, ngày ban hành và ngày có hiệu lực.
2. BÁO CHÍ, THỜI SỰ & GOOGLE SEARCH CHÍNH XÁC (DẪN NGUỒN ĐÚNG LÚC):
   - Khi câu hỏi liên quan đến tin tức, thời sự, giá cả, video YouTube, repo GitHub, hoặc khi người dùng yêu cầu link/nguồn kiểm chứng:
     BẮT BUỘC dựa vào dữ liệu thực tế được cập nhật trực tuyến năm 2026.
   - NGUYÊN TẮC VỀ NGUỒN VÀ LIÊN KẾT (MẶC ĐỊNH KHÔNG XUẤT):
     + MẶC ĐỊNH TUYỆT ĐỐI KHÔNG xuất mục Nguồn Dẫn Chứng hay chèn link bừa bãi vào câu trả lời thông thường.
     + CHỈ xuất mục '### 🌐 Nguồn Dẫn Chứng & Tham Khảo' khi người dùng CHỦ ĐỘNG HỎI HOẶC YÊU CẦU ĐƯỜNG DẪN/NGUỒN.
     + TUYỆT ĐỐI KHÔNG TỰ BỊA ĐẶT TIN TỨC, không tạo đường link ảo khi không có căn cứ xác thực.
3. NGHỊ QUYẾT HĐND / VĂN BẢN ĐỊA PHƯƠNG:
   - Nghị quyết của Hội đồng nhân dân (NQ-HĐND): Mỗi tỉnh/thành phố có một Nghị quyết riêng (ví dụ: Nghị quyết 16/2025/NQ-HĐND tỉnh An Giang có hiệu lực từ 01/01/2026, Nghị quyết 16/2024/NQ-HĐND tỉnh Bình Định...). Phải phân biệt rõ ràng tỉnh/thành phố cụ thể, không phỏng đoán mơ hồ.
3. CHẤT LƯỢNG CAO NHẤT, ĐÀO SÂU BẢN CHẤT:
   - Mọi câu trả lời chuyên môn, kế hoạch, văn bản phải được viết hoàn chỉnh từ đầu đến cuối, chặt chẽ, đầy đủ căn cứ, không dùng 'v.v.', 'bạn tự điền tiếp'.
   - Nếu có dữ liệu tra cứu trực tuyến đính kèm bên dưới, phải sử dụng làm căn cứ chính xác cao nhất.
4. GIAO TIẾP TỰ NHIÊN - TUYỆT ĐỐI KHÔNG XUẤT LỆNH MÁY HOẶC JSON TOOL:
   - Tuyệt đối không xuất mã JSON gọi công cụ như 'action': 'dalle.text2im', 'action_input', v.v. Hãy luôn trò chuyện lịch thiệp, tự nhiên bằng tiếng Việt với anh Trường.
5. MINH BẠCH VỀ NỀN TẢNG CÔNG NGHỆ:
   - Bạn là KINI AI, vận hành thông qua kết nối Google Gemini API chính thức. Tuyệt đối không tự suy diễn hoặc tự nhận mình là phiên bản cũ 'Gemini 1.5 Pro' từ dữ liệu huấn luyện đóng băng cũ. Hãy luôn trung thực và trả lời khách quan.
6. TRUNG THỰC SỐ HỌC VÀ TÍNH TOÁN LOGIC (DOUBLE-CHECK MATH):
   - Khi tính toán số liệu, tiền bạc, cân nặng (lạng, kg), đơn hàng: BẮT BUỘC liệt kê chi tiết phép tính từng bước và kiểm tra lại hai chiều (ví dụ 33 + 50 + 43 = 126). Tuyệt đối không phỏng đoán theo xác suất từ ngữ, đảm bảo chính xác 100%.
7. NGUYÊN TẮC 'LÀM THẬT MỚI ĐƯỢC BÁO CÁO THẬT':
   - Tuyệt đối không tự bịa ra văn bản giả vờ rằng mình đã tạo file hay chạy server trên máy tính khi đang trong luồng hội thoại văn bản thông thường. Chỉ báo cáo đã tạo file khi có kết quả thực thi thực tế từ công cụ Agent.
8. NGUYÊN TẮC TRẢ LỜI 3 CHIỀU THỰC CHIẾN (360° ACTIONABILITY - ĐẠT ĐIỂM 10 TUYỆT ĐỐI):
   - Khi trả lời về giá cả tài sản, tiền mã hóa (crypto, Pi, BTC), tin tức, chính sách, thủ tục, công nghệ hay bất kỳ vấn đề thực tế nào, TUYỆT ĐỐI KHÔNG CHỈ ĐƯA CON SỐ TRÊN SÁCH VỞ/SÀN MỘT CÁCH VÔ HỒN.
   - BẮT BUỘC PHẢI PHÂN TÍCH ĐẦY ĐỦ 3 CHIỀU THỰC TẾ:
     * Chiều 1 (Dữ liệu cốt lõi chuẩn xác): Đưa con số thời gian thực, có quy đổi sang tiền Việt (VNĐ) rõ ràng và nêu biến động.
     * Chiều 2 (Thực tế áp dụng & Khả năng thanh khoản): Phải trả lời thẳng vào điều người dùng thực sự quan tâm: Số liệu này trong thực tế có rút/nạp/bán/dùng được ngay không? Điều kiện cần là gì? (Ví dụ: Với Pi Network, phải nêu rõ giá trên sàn quốc tế là IOU phái sinh, app điện thoại chưa mở nạp lên sàn bán tự do, muốn bán lấy tiền mặt tại Việt Nam hiện chủ yếu qua thỏa thuận P2P trực tiếp giữa người mua và người bán).
     * Chiều 3 (Cảnh báo rủi ro & Lời khuyên an toàn): Cảnh báo thẳng thắn các cạm bẫy thổi phồng giá ảo, lừa đảo, rủi ro pháp lý/tài chính để bảo vệ tuyệt đối an toàn cho anh Trường."""

def is_image_request(text: str, history: Optional[List[Dict[str, str]]] = None) -> bool:
    """Kiểm tra xem người dùng có đang yêu cầu vẽ tranh / tạo ảnh / làm logo / thiết kế poster / sửa ảnh / đổi thông tin ảnh không"""
    import unicodedata
    t = unicodedata.normalize('NFC', text.lower().strip())

    # 0. LOẠI TRỪ NGAY LẬP TỨC các yêu cầu về tài liệu, file văn bản, báo cáo, kế hoạch, code, app/game, thư mục hoặc desktop:
    # Tuyệt đối không được nhầm lẫn giữa "màn hình" (desktop screen), "tạo game/web/thư mục" với "vẽ ảnh"!
    exclude_keywords = [
        "docx", "doc", "word", "excel", "xlsx", "pdf", "file", "tệp",
        "thư mục", "folder", "game", "trò chơi", "ứng dụng", "website", "trang web",
        "html", "python", "lập trình", "chương trình", "phần mềm",
        "bài hát", "bài văn", "kịch bản", "danh sách", "bảng tính",
        "báo cáo", "kế hoạch", "văn bản", "soạn thảo", "viết code", "script",
        "màn hình desktop", "trên desktop", "ngoài desktop", "desktop"
    ]
    has_exclude = any(k in t for k in exclude_keywords) or bool(re.search(r'\b(app|web|code)\b', t))
    has_explicit_draw = any(d in t for d in [
        "vẽ ảnh", "vẽ bức ảnh", "vẽ tranh", "vẽ bức tranh", "vẽ hình", "vẽ logo", 
        "tạo ảnh", "tạo bức ảnh", "sinh ảnh", "chụp ảnh", "vẽ cho anh", "vẽ cho tôi",
        "vẽ giúp anh", "vẽ giúp tôi", "thiết kế logo", "làm logo"
    ])
    if has_exclude and not has_explicit_draw:
        return False

    # Thay thế các từ ghép tiếng Việt có chữ "hình" (màn hình, tình hình, mô hình, cấu hình...)
    # để tránh bị regex \bhình\b khớp nhầm!
    t_clean = re.sub(r'\bmàn\s+hình\b', 'desktop_display', t)
    t_clean = re.sub(r'\btình\s+hình\b', 'situation_context', t_clean)
    t_clean = re.sub(r'\bmô\s+hình\b', 'model_concept', t_clean)
    t_clean = re.sub(r'\bcấu\s+hình\b', 'configuration_setting', t_clean)

    # 1. Bắt đầu bằng lệnh vẽ / tạo / thiết kế / sửa ảnh
    if re.search(r'^(hãy\s+)?(vẽ|tạo\s+ảnh|tạo\s+logo|thiết\s+kế\s+logo|thiết\s+kế\s+poster|làm\s+logo|sửa\s+ảnh|chỉnh\s+sửa\s+ảnh|sửa\s+hình|sửa\s+logo|chỉnh\s+ảnh|remix\s+ảnh|làm\s+lại\s+ảnh)\b', t_clean):
        return True
        
    # 2. Khớp các mẫu câu tạo/vẽ/thiết kế/sửa ảnh/logo/poster/banner/cờ/chân dung/phong cảnh
    patterns = [
        r'\b(vẽ|tạo|làm|thiết kế|sinh|chụp|render|sửa|chỉnh sửa|remix|biến thể|làm lại|vẽ lại)\s+.*?(ảnh|bức ảnh|tấm ảnh|hình|bức hình|tranh|bức tranh|logo|poster|banner|icon|avatar|sticker|hình ảnh|lá cờ|quốc kỳ|cờ tổ quốc|cờ việt nam|cờ đỏ|huy hiệu|phong cảnh|chân dung)\b',
        r'\b(vẽ|tạo|thiết kế|làm|sửa|chỉnh)\s+(cho\s+)?(tôi|anh|em|mình|người dùng)?\s*.*?(ảnh|logo|poster|banner|icon|tranh|hình|lá cờ|quốc kỳ|cờ tổ quốc|cờ việt nam|huy hiệu)\b',
        r'^(tạo|vẽ|làm|thiết kế|sửa|chỉnh)\s+(logo|ảnh|poster|banner|hình|tranh|icon|avatar|lá cờ|quốc kỳ|cờ tổ quốc|cờ việt nam|huy hiệu)\b',
        r'\b(generate\s+image|draw|create\s+image|text\s*to\s*image|txt2img|make\s+a\s+picture|draw\s+a|design\s+logo|edit\s+image|remix\s+image)\b',
        r'\b(đổi|thay|sửa|thêm|bổ sung)\s+(số\s+điện\s+thoại|sđt|phone|tên|chữ|text|thông\s+tin|chi\s+tiết|màu|nền)\s+(thành|sang|thành\s+số|thành\s+chữ|vào)?\b',
        r'\b(đổi|thay|sửa)\s+(thành\s+số|thành\s+chữ)\s+\d+\b'
    ]
    for p in patterns:
        if re.search(p, t_clean):
            return True
            
    # 3. Từ khóa thông dụng mở rộng
    keywords = [
        "vẽ cho tôi", "vẽ cho anh", "vẽ giúp anh", "vẽ giúp em", "vẽ giúp tôi", 
        "vẽ ảnh", "vẽ bức ảnh", "vẽ tranh", "tạo ảnh", "tạo bức ảnh", "sinh ảnh",
        "vẽ hình", "tạo hình", "thiết kế logo", "vẽ logo", "làm logo", "tạo logo",
        "thiết kế poster", "tạo poster", "làm poster", "vẽ poster", "thiết kế banner", "tạo banner",
        "sửa ảnh", "chỉnh sửa ảnh", "sửa hình", "sửa logo", "sửa ảnh này", "sửa bức ảnh", "chỉnh ảnh",
        "đổi số điện thoại", "đổi sđt", "thay số điện thoại", "thêm số điện thoại", "sửa số điện thoại",
        "đổi tên thành", "thay tên thành", "đổi chữ thành", "sửa chữ thành",
        "generate image", "draw an image", "create an image", "paint a", "sketch a", "edit image"
    ]
    if any(k in t for k in keywords):
        return True

    # 4. Ngữ cảnh nối tiếp: Nếu câu ngay trước vừa tạo ảnh (FLUX.1 / KINI Art Studio) và người dùng nhắn ngắn gọn "tạo ...", "đổi ...", "thêm ..."
    if history and re.match(r'^(tạo|vẽ|làm|đổi|thay|sửa|chỉnh|thêm|cho)\s+', t_clean):
        for pm in reversed(history[-4:]):
            if pm.get("role") == "assistant" and any(tag in pm.get("content", "") for tag in ["FLUX.1", "KINI Art Studio", "Tác phẩm"]):
                return True

    return False

def clean_image_prompt(text: str, history: Optional[List[Dict[str, str]]] = None) -> str:
    """Lọc bỏ các tiền tố ra lệnh vẽ / sửa và neo ngữ cảnh ảnh trước đó nếu người dùng đang chỉnh sửa nối tiếp"""
    import unicodedata
    t = unicodedata.normalize('NFC', text.strip())
    prefixes = [
        r'^(hãy\s+)?(vẽ|tạo|làm|thiết kế|sinh|render|sửa|chỉnh sửa|remix)\s+(cho\s+)?(tôi|anh|em|mình|bạn|người dùng)?\s*(giúp\s+)?(tôi|anh|em|mình)?\s*(một\s+)?(bức\s+ảnh|bức\s+tranh|tấm\s+ảnh|hình\s+ảnh|bức\s+hình|hình|ảnh|tranh|logo|poster|banner|icon|avatar)?\s*(này\s+)?(về|có|là|:|như\s+sau:)?\s*',
        r'^(vẽ|tạo|thiết kế|làm|sửa|chỉnh)\s+(logo|ảnh|poster|banner|hình|tranh|icon|avatar)\s*(này\s+)?(về|có|là|:)?\s*'
    ]
    for p in prefixes:
        t = re.sub(p, '', t, flags=re.IGNORECASE).strip()
    cleaned = t if len(t) > 2 else text.strip()

    # Nếu là lệnh chỉnh sửa nối tiếp (VD: "đổi nền xanh", "thêm mây trắng", "làm lại đẹp hơn") -> ghép với chủ đề ảnh gần nhất
    if history and re.match(r'^(đổi|thay|sửa|chỉnh|thêm|bớt|cho|làm lại)\b', unicodedata.normalize('NFC', text.lower().strip())):
        for pm in reversed(history[-4:]):
            if pm.get("role") == "assistant":
                m_subj = re.search(r'Chủ đề:\*\*\s*\*"([^"]+)"\*', pm.get("content", ""))
                if m_subj:
                    prev_subj = m_subj.group(1).strip()
                    if prev_subj.lower() not in cleaned.lower():
                        return f"{prev_subj}, {cleaned}"
    return cleaned


def build_conversation_focus_anchor(messages: List[Dict[str, str]]) -> str:
    """Tạo điểm neo trọng tâm hội thoại giúp AI luôn ghi nhớ và tập trung vào chủ đề đang làm việc."""
    if not messages or len(messages) < 2:
        return ""
    user_msgs = [m.get("content", "").strip() for m in messages if m.get("role") == "user" and m.get("content", "").strip()]
    if len(user_msgs) < 2:
        return ""
    first_goal = user_msgs[0].replace("\n", " ")[:180]
    recent_turns = [u.replace("\n", " ")[:150] for u in user_msgs[-3:-1]]
    lines = [
        "=== TRỌNG TÂM & GHI NHỚ BỐI CẢNH ĐANG LÀM VIỆC TRONG PHIÊN NÀY ===",
        f"- Mục tiêu khởi đầu của phiên: {first_goal}",
    ]
    if recent_turns:
        lines.append("- Các yêu cầu/chi tiết vừa trao đổi ngay trước đó: " + " | ".join(recent_turns))
    lines.append("- BẮT BUỘC: Giữ mạch tư duy tập trung vào đúng chủ đề trên, ghi nhớ mọi chi tiết/tên/thông số người dùng đã nêu trong phiên này để trả lời liền mạch, không lạc đề.")
    return "\n".join(lines)

def build_system_instruction_with_memories(base_prompt: Optional[str] = None, client_id: str = "master") -> str:
    """Ghép nối System Prompt với thời gian thực, quy tắc chính xác và ký ức dài hạn"""
    from . import database
    
    # Đọc danh tính đã cài đặt cho thiết bị / client_id này
    is_owner_val = database.get_setting("is_owner", "1" if client_id == "master" else "0", client_id=client_id)
    user_email = database.get_setting("user_email", "", client_id=client_id).strip().lower()
    user_call_name = database.get_setting("user_call_name", "", client_id=client_id).strip()
    user_name = database.get_setting("user_name", "", client_id=client_id).strip()
    ai_call_name = database.get_setting("ai_call_name", "", client_id=client_id).strip()
    
    # Chỉ coi là anh Trường khi đúng email của anh HOẶC (is_owner == "1" và tên xưng hô là Anh Trường)
    is_truong_owner = (user_email == "haitruongproqt1@gmail.com") or (is_owner_val == "1" and user_call_name in ["Anh Trường", "Phùng Hải Trường"])
    
    if is_truong_owner:
        # CHỦ NHÂN KINI AI: PHÙNG HẢI TRƯỜNG
        custom_p = database.get_setting("custom_persona", "", client_id=client_id)
        sys_inst = base_prompt or custom_p or DEFAULT_SYSTEM_PROMPT
        sys_inst += f"\n\n{get_current_time_context()}"
        sys_inst += f"\n\n{get_precision_rules()}"
        try:
            memories = database.get_all_memories(limit=30, client_id="master")
            if memories:
                facts = "\n".join(f"- {m['fact']}" for m in memories)
                sys_inst += f"\n\n=== BỘ NHỚ DÀI HẠN VỀ ANH HẢI TRƯỜNG (LUÔN GHI NHỚ) ===\n{facts}"
        except Exception as e:
            logger.warning(f"Lỗi đọc bộ nhớ: {e}")
        return sys_inst
    else:
        # THIẾT BỊ NGƯỜI DÙNG KHÁC / TÀI KHOẢN MỚI CÀI ĐẶT RIÊNG:
        user_call = user_call_name or "Bạn"
        ai_call = ai_call_name or "Tôi"
        u_name = user_name or "Người dùng"
        
        sys_inst = f"""[SYSTEM IDENTITY: KINI AI - SIÊU TRỢ LÝ TRÍ TUỆ NHÂN TẠO CÁ NHÂN]
- Bạn là KINI AI - mô hình trợ lý trí tuệ nhân tạo thông minh, hiện đại, chuẩn mực và đa năng.
- QUY TẮC XƯNG HÔ THIẾT LẬP CHO NGƯỜI DÙNG HIỆN TẠI:
  + Tên người dùng: "{u_name}".
  + Bạn BẮT BUỘC gọi người dùng là: "{user_call}".
  + Bạn BẮT BUỘC tự xưng là: "{ai_call}".
  + TUYỆT ĐỐI chỉ xưng hô đúng theo quy tắc trên và KHÔNG mang bất kỳ ký ức hay thông tin của ai khác vào đây, vì đây là không gian làm việc và huấn luyện hoàn toàn độc lập, riêng tư của {user_call} ({u_name}).

[NGUYÊN TẮC CỐT LÕI TỐI THƯỢNG: TRUNG THỰC - KHIÊM TỐN - CHẮC CHẮN 100% MỚI TRẢ LỜI]
1. TRUNG THỰC & BIẾT RÕ BẢN THÂN:
   - Khi biết chắc chắn 100%: Trả lời rõ ràng, sắc bén, đi thẳng vào bản chất và giải pháp thực tế.
   - Khi KHÔNG chắc chắn hoặc thiếu thông tin: BẮT BUỘC phải nói thật: "Thưa {user_call}, phần này {ai_call} chưa có đủ dữ liệu / chưa kiểm chứng chắc chắn 100%...". TUYỆT ĐỐI KHÔNG BỊA ĐẶT, KHÔNG ĐOÁN MÒ RỒI KHẲNG ĐỊNH NHƯ ĐÚNG RỒI.
2. NGUYÊN TẮC HÀNH ĐỘNG 360° (TOÀN DIỆN & HÀNH ĐỘNG THỰC TẾ):
   - Mọi câu trả lời về thị trường, tài chính, giao dịch hay công nghệ đều phân tích đa chiều (Giá niêm yết, Thực tế giao dịch, Rủi ro, Lời khuyên hành động an toàn).
3. TƯ DUY TOÁN HỌC & LOGIC:
   - Tuyệt đối không đoán mò số liệu hay phép tính. Luôn kiểm tra 2 chiều (Double-check) trước khi đưa ra kết quả.
4. QUY TẮC NGUỒN DẪN CHỨNG:
   - Mặc định không xuất danh sách nguồn dài dòng, chỉ hiện khi {user_call} chủ động yêu cầu."""
        
        sys_inst += f"\n\n{get_current_time_context()}"
        sys_inst += f"\n\n{get_precision_rules()}"
        
        try:
            user_memories = database.get_all_memories(limit=30, client_id=client_id)
            if user_memories:
                facts = "\n".join(f"- {m['fact']}" for m in user_memories)
                sys_inst += f"\n\n=== BỘ NHỚ DÀI HẠN VỀ {user_call.upper()} (LUÔN GHI NHỚ) ===\n{facts}"
        except Exception as e:
            logger.warning(f"Lỗi đọc bộ nhớ cá nhân: {e}")
            
        return sys_inst

def extract_and_save_memory_async(user_text: str, api_key: str = "", client_id: str = "master"):
    """Tự động phân tích xem người dùng có chia sẻ thông tin cá nhân/thói quen để lưu vào bộ nhớ không"""
    from . import database
    if len(user_text.strip()) < 10:
        return

    hints = [
        "tôi tên", "anh tên", "tôi thích", "anh thích", "tôi làm", "anh làm", "nghề của", 
        "dự án", "hãy nhớ", "nhớ rằng", "nhớ nhé", "quy tắc", "nguyên tắc", "từ nay", 
        "lưu ý", "luôn luôn", "không được", "anh dùng", "máy của anh", "vợ tôi", "con tôi", "nhà tôi"
    ]
    if not any(h in user_text.lower() for h in hints):
        return

    sys_extract = (
        "Bạn là module trích xuất ký ức cá nhân. Hãy đọc câu của người dùng và trích xuất 1 câu ngắn gọn về sự thật/sở thích/thông tin cá nhân cần ghi nhớ vĩnh viễn (ví dụ: 'Người dùng làm việc tại...', 'Sở thích của người dùng là...'). "
        "Nếu không có thông tin cá nhân quan trọng, chỉ trả lời 'NONE'. Không giải thích gì thêm."
    )
    try:
        res = ask_gemini(
            messages=[{"role": "user", "content": user_text}],
            api_key=api_key,
            system_instruction=sys_extract,
            client_id=client_id
        )
        if res.get("success") and res.get("reply"):
            fact = res["reply"].strip().replace('"', '')
            if fact and fact != "NONE" and len(fact) < 200:
                database.add_memory(fact, category="auto", client_id=client_id)
                logger.info(f"Đã tự động ghi nhớ ký ức mới: {fact} (client: {client_id})")
    except Exception as e:
        logger.warning(f"Lỗi trích xuất ký ức: {e}")


def _split_api_keys(raw: str) -> List[str]:
    if not raw:
        return []
    return [k.strip() for k in re.split(r"[\s,;]+", raw.strip()) if k.strip() and len(k.strip()) >= 10]


def get_api_key_pool(api_key: Optional[str] = None, client_id: str = "master") -> List[str]:
    """Lấy danh sách Gemini API Key (hỗ trợ xoay vòng nhiều key phân tách bằng dấu phẩy/xuống dòng)."""
    from . import database
    candidates: List[str] = []
    for src in (
        api_key or "",
        database.get_setting("gemini_api_key", "", client_id=client_id),
        database.get_setting("gemini_api_keys_pool", "", client_id=client_id),
        database.get_setting("gemini_api_key", "", client_id="master"),
        database.get_setting("gemini_api_keys_pool", "", client_id="master"),
        os.environ.get("GEMINI_API_KEY", ""),
    ):
        for k in _split_api_keys(src):
            if k not in candidates:
                candidates.append(k)
    return candidates


def try_ollama_fallback(
    messages: List[Dict[str, str]],
    system_instruction: str = "",
    client_id: str = "master",
) -> Optional[Dict[str, Any]]:
    """Dự phòng gọi Model Offline cục bộ (Ollama) nếu toàn bộ Gemini Key gặp sự cố hoặc mất mạng."""
    from . import database
    ollama_enabled = database.get_setting("ollama_enabled", "0", client_id=client_id)
    base_url = (database.get_setting("ollama_base_url", "http://127.0.0.1:11434", client_id=client_id) or "http://127.0.0.1:11434").rstrip("/")
    model_name = (database.get_setting("ollama_model", "kini-ai", client_id=client_id) or "kini-ai").strip()
    try:
        probe = requests.get(f"{base_url}/api/tags", timeout=1.5 if ollama_enabled != "1" else 3.0)
        if probe.status_code != 200:
            return None
        tags = [m.get("name", "") for m in probe.json().get("models", [])]
        if not tags:
            return None
        chosen_model = model_name if any(t.startswith(model_name) for t in tags) else tags[0]
        ollama_msgs = []
        if system_instruction:
            ollama_msgs.append({"role": "system", "content": system_instruction})
        for m in messages[-10:]:
            ollama_msgs.append({"role": "user" if m["role"] == "user" else "assistant", "content": m["content"]})
        r = requests.post(
            f"{base_url}/api/chat",
            json={"model": chosen_model, "messages": ollama_msgs, "stream": False},
            timeout=45,
        )
        if r.status_code == 200:
            reply = r.json().get("message", {}).get("content", "").strip()
            if reply:
                return {
                    "success": True,
                    "reply": reply,
                    "model_used": f"ollama/{chosen_model}",
                    "target_model": f"ollama/{chosen_model}",
                    "is_fallback": True,
                    "fallback_reason": "Đã tự động chuyển sang Model Offline cục bộ (Ollama) để đảm bảo phản hồi liên tục.",
                }
    except Exception:
        return None
    return None


def is_hard_question(text: str, model_mode: str = "flash") -> bool:
    """Nhận diện câu hỏi khó / phức tạp cần chạy bước Tự Phản Biện (Self-Verification)."""
    import unicodedata
    t = unicodedata.normalize("NFC", (text or "").lower().strip())
    if len(t) < 25:
        return False
    if "```" in t or t.startswith("/plan") or t.startswith("/agent"):
        return False
    if model_mode == "pro":
        return True
    hard_cues = [
        "phân tích", "chứng minh", "so sánh", "tại sao", "vì sao", "giải thích chi tiết",
        "luật", "nghị định", "thông tư", "điều khoản", "tính toán", "kiểm chứng",
        "chiến lược", "kiến trúc", "tối ưu", "sửa lỗi", "debug", "đánh giá rủi ro",
        "tổng hợp", "bộ tiêu chí", "phản biện",
    ]
    if len(t) >= 60 and any(c in t for c in hard_cues):
        return True
    return len(t) >= 240


def verify_and_refine_answer(
    user_query: str,
    draft_answer: str,
    grounded_context: str = "",
    api_key: Optional[str] = None,
    client_id: str = "master",
) -> str:
    """
    Bước 2 (Tự phản biện): Rà soát lại phép tính, logic, điều kiện biên và độ khớp dữ liệu thực tế.
    Trả về 'VERIFIED_OK' nếu bản nháp đã chuẩn, hoặc trả về bản đã hiệu đính hoàn chỉnh.
    """
    if not draft_answer or len(draft_answer) < 80 or "```html" in draft_answer.lower():
        return "VERIFIED_OK"

    verifier_prompt = (
        "Bạn là Bộ Kiểm Chứng Độc Lập (Self-Verifier) của KINI AI.\n"
        "Hãy rà soát nhanh câu trả lời nháp dựa trên câu hỏi người dùng và dữ liệu thực tế đính kèm (nếu có).\n"
        "Kiểm tra nghiêm ngặt: (1) Sai sót số học/cộng trừ nhân chia, (2) Mâu thuẫn logic hoặc thiếu điều kiện quan trọng, (3) Bịa đặt số liệu/trích dẫn không có trong dữ liệu.\n"
        "- Nếu câu trả lời nháp ĐÃ CHÍNH XÁC VÀ ĐẦY ĐỦ: chỉ trả lời duy nhất cụm từ `VERIFIED_OK`.\n"
        "- Nếu phát hiện sai sót hoặc điểm cần bổ sung: viết lại câu trả lời HOÀN CHỈNH đã sửa chuẩn xác (giữ nguyên xưng hô chuẩn, không cần giải thích dài dòng về quá trình kiểm tra)."
    )
    user_payload = (
        f"[CÂU HỎI]:\n{user_query}\n\n"
        + (f"[DỮ LIỆU THỰC TẾ ĐỐI CHIẾU]:\n{grounded_context[:3500]}\n\n" if grounded_context else "")
        + f"[CÂU TRẢ LỜI NHÁP]:\n{draft_answer[:5000]}"
    )
    res = ask_gemini(
        messages=[{"role": "user", "content": user_payload}],
        api_key=api_key,
        system_instruction=verifier_prompt,
        model_mode="flash-3.5",
        client_id=client_id,
    )
    if res.get("success") and res.get("reply"):
        checked = res["reply"].strip()
        if checked == "VERIFIED_OK" or checked.startswith("VERIFIED_OK"):
            return "VERIFIED_OK"
        if len(checked) >= 40:
            return checked
    return "VERIFIED_OK"


def ask_gemini(
    messages: List[Dict[str, str]], 
    api_key: Optional[str] = None, 
    system_instruction: Optional[str] = None,
    image_base64: Optional[str] = None,
    image_mime: str = "image/jpeg",
    model_mode: str = "flash",
    client_id: str = "master",
    extra_images: Optional[List[Dict[str, str]]] = None
) -> Dict[str, Any]:
    """
    Gửi câu hỏi / hội thoại tới Google Gemini API với nhiệt độ thấp (0.15) để đảm bảo độ chuẩn xác tối đa.
    Hỗ trợ xoay vòng nhiều API Key (Multi-Key Pool) và dự phòng Model Offline (Ollama).
    """
    from . import database
    key_pool = get_api_key_pool(api_key=api_key, client_id=client_id)
    if not key_pool:
        ollama_res = try_ollama_fallback(messages, system_instruction=system_instruction or "", client_id=client_id)
        if ollama_res:
            return ollama_res
        return {
            "success": False,
            "reply": "⚠️ Bạn chưa cấu hình **Google Gemini API Key**! Vui lòng vào mục **⚙️ Cài Đặt** để nhập API Key của bạn."
        }
    key = key_pool[0]

    contents = []
    for msg in messages:
        role = "user" if msg["role"] == "user" else "model"
        contents.append({
            "role": role,
            "parts": [{"text": msg["content"]}]
        })

    # Nếu có ảnh đính kèm (Vision - hỗ trợ đơn lẻ và nhiều ảnh cùng lúc)
    if (image_base64 or extra_images) and contents:
        if image_base64:
            contents[-1]["parts"].append({
                "inline_data": {
                    "mime_type": image_mime,
                    "data": image_base64
                }
            })
        for img in (extra_images or []):
            if img.get("base64"):
                contents[-1]["parts"].append({
                    "inline_data": {
                        "mime_type": img.get("mime", "image/jpeg"),
                        "data": img["base64"]
                    }
                })

    # Cấu hình nhiệt độ thấp (0.15) để loại bỏ ảo giác, đảm bảo tính chuẩn xác và trung thực tuyệt đối
    payload = {
        "contents": contents,
        "generationConfig": {
            "temperature": 0.15,
            "topP": 0.95,
            "maxOutputTokens": 8192
        }
    }

    # Gắn System Instruction kèm thời gian thực, quy tắc chính xác, bộ nhớ và trọng tâm phiên
    sys_inst = system_instruction or build_system_instruction_with_memories(client_id=client_id)
    if not system_instruction:
        focus_anchor = build_conversation_focus_anchor(messages)
        if focus_anchor:
            sys_inst = f"{sys_inst}\n\n{focus_anchor}"
    if sys_inst:
        payload["systemInstruction"] = {
            "parts": [{"text": sys_inst}]
        }

    # Lựa chọn danh sách mô hình dựa trên model_mode
    if model_mode in ["flash-3.5", "gemini-3.5-flash"]:
        models_to_try = [
            "gemini-3.5-flash",
            "gemini-3.1-flash-lite",
            "gemini-flash-lite-latest"
        ]
    elif model_mode in ["flash-3.8", "gemini-3.8-flash"]:
        models_to_try = [
            "gemini-3.8-flash",         # Mô hình 3.8 Flash thế hệ mới nhất
            "gemini-3.5-flash",         # Fallback 1: Siêu thông minh 3.5
            "gemini-3.1-flash-lite",    # Fallback 2: Siêu tốc 100% ổn định
            "gemini-flash-lite-latest"
        ]
    elif model_mode == "pro":
        models_to_try = [
            "gemini-2.5-pro",           # Bản Pro ổn định nhất
            "gemini-3.1-pro-preview",   # Bản 3.1 Pro mới
            "gemini-3.5-flash",         # Fallback thông minh cao cấp nếu hết quota Pro
            "gemini-3.1-flash-lite",
            "gemini-flash-lite-latest"
        ]
    else:
        # Flash Lite mode: siêu tốc < 1.0s, cực kỳ ổn định, chính xác cao
        models_to_try = [
            "gemini-3.1-flash-lite",    # Siêu tốc ~0.8s, hoạt động 100%
            "gemini-3.5-flash",         # Thông minh cao cấp
            "gemini-flash-lite-latest"  # Fallback chuẩn
        ]
    
    last_error = ""
    for model_name in models_to_try:
        for active_key in key_pool:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent?key={active_key}"
            try:
                req_timeout = 15
                res = requests.post(url, json=payload, timeout=req_timeout)
                if res.status_code == 200:
                    data = res.json()
                    text = data["candidates"][0]["content"]["parts"][0]["text"]
                    
                    # Ghi nhận Quota & Token thực tế từ Google
                    try:
                        from . import database
                        usage = data.get("usageMetadata", {})
                        p_tok = usage.get("promptTokenCount", 0)
                        c_tok = usage.get("candidatesTokenCount", 0)
                        t_tok = usage.get("totalTokenCount", 0)
                        database.record_api_usage(model_name, p_tok, c_tok, t_tok, client_id=client_id)
                    except Exception:
                        pass

                    is_fb = (model_name != models_to_try[0])
                    fb_reason = ""
                    if is_fb:
                        fb_reason = f"Mô hình {models_to_try[0]} từ Google tạm thời quá tải hoặc chạm hạn mức, KINI đã chuyển tiếp sang {model_name} để phản hồi liền mạch."

                    return {
                        "success": True,
                        "reply": text,
                        "model_used": model_name,
                        "target_model": models_to_try[0],
                        "is_fallback": is_fb,
                        "fallback_reason": fb_reason,
                        "fallback_from_38": (model_mode in ["flash-3.8", "gemini-3.8-flash"] and model_name != "gemini-3.8-flash"),
                        "usage": data.get("usageMetadata", {})
                    }
                else:
                    err_json = res.json() if res.headers.get("content-type", "").startswith("application/json") else {}
                    err_msg = err_json.get("error", {}).get("message", res.text[:200])
                    last_error = f"HTTP {res.status_code}: {err_msg}"
                    if res.status_code in (401, 403, 429):
                        continue  # Xoay sang key kế tiếp trong pool
                    break  # Lỗi model (404/503), chuyển model kế tiếp
            except Exception as e:
                last_error = str(e)
                break

    ollama_res = try_ollama_fallback(messages, system_instruction=sys_inst or "", client_id=client_id)
    if ollama_res:
        return ollama_res

    return {
        "success": False,
        "reply": f"❌ Không thể kết nối với dịch vụ Gemini ({last_error}). Vui lòng kiểm tra lại kết nối mạng hoặc tính hợp lệ của API Key."
    }

def ask_gemini_stream(
    messages: List[Dict[str, str]],
    api_key: str = "",
    image_base64: Optional[str] = None,
    image_mime: str = "image/jpeg",
    system_instruction: Optional[str] = None,
    model_mode: str = "flash",
    client_id: str = "master",
    extra_images: Optional[List[Dict[str, str]]] = None
):
    """
    Phát trực tuyến (Streaming SSE) câu trả lời từ Google Gemini từng từ thời gian thực.
    Yields dict: {"chunk": text, "done": False, "model_used": model_name}
    Final yield: {"done": True, "full_text": full_text, "model_used": model_name}
    """
    from . import database
    key_pool = get_api_key_pool(api_key=api_key, client_id=client_id)
    if not key_pool:
        ollama_res = try_ollama_fallback(messages, system_instruction=system_instruction or "", client_id=client_id)
        if ollama_res:
            yield {"chunk": ollama_res["reply"], "done": False, "model_used": ollama_res["model_used"]}
            yield {"done": True, "full_text": ollama_res["reply"], "model_used": ollama_res["model_used"]}
            return
        yield {"error": "Chưa cài đặt Gemini API Key. Vui lòng vào Cài đặt để dán API Key của bạn.", "done": True}
        return
    key = key_pool[0]

    # Chuẩn bị contents
    contents = []
    for msg in messages:
        role = "user" if msg["role"] == "user" else "model"
        parts = [{"text": msg["content"]}]
        contents.append({"role": role, "parts": parts})

    if (image_base64 or extra_images) and contents:
        last_user_idx = -1
        for i in range(len(contents) - 1, -1, -1):
            if contents[i]["role"] == "user":
                last_user_idx = i
                break
        if last_user_idx != -1:
            if image_base64:
                contents[last_user_idx]["parts"].append({
                    "inlineData": {
                        "mimeType": image_mime,
                        "data": image_base64
                    }
                })
            for img in (extra_images or []):
                if img.get("base64"):
                    contents[last_user_idx]["parts"].append({
                        "inlineData": {
                            "mimeType": img.get("mime", "image/jpeg"),
                            "data": img["base64"]
                        }
                    })

    payload = {
        "contents": contents,
        "generationConfig": {
            "temperature": 0.4,
            "topP": 0.95,
            "maxOutputTokens": 8192
        }
    }

    sys_inst = system_instruction or build_system_instruction_with_memories(client_id=client_id)
    if not system_instruction:
        focus_anchor = build_conversation_focus_anchor(messages)
        if focus_anchor:
            sys_inst = f"{sys_inst}\n\n{focus_anchor}"
    if sys_inst:
        payload["systemInstruction"] = {
            "parts": [{"text": sys_inst}]
        }

    # Chọn danh sách mô hình
    if model_mode in ["flash-3.5", "gemini-3.5-flash"]:
        models_to_try = ["gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-flash-lite-latest"]
    elif model_mode in ["flash-3.8", "gemini-3.8-flash"]:
        models_to_try = ["gemini-3.8-flash", "gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-flash-lite-latest"]
    elif model_mode == "pro":
        models_to_try = ["gemini-2.5-pro", "gemini-3.1-pro-preview", "gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-flash-lite-latest"]
    else:
        models_to_try = ["gemini-3.1-flash-lite", "gemini-3.5-flash", "gemini-flash-lite-latest"]

    for model_name in models_to_try:
        for active_key in key_pool:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:streamGenerateContent?alt=sse&key={active_key}"
            accumulated_text = ""
            try:
                res = requests.post(url, json=payload, stream=True, timeout=12)
                if res.status_code == 200:
                    for line in res.iter_lines():
                        if line:
                            decoded = line.decode("utf-8")
                            if decoded.startswith("data: "):
                                raw_json = decoded[6:].strip()
                                if raw_json:
                                    try:
                                        chunk_data = json.loads(raw_json)
                                        parts = chunk_data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
                                        for p in parts:
                                            chunk_txt = p.get("text", "")
                                            if chunk_txt:
                                                accumulated_text += chunk_txt
                                                yield {
                                                    "chunk": chunk_txt,
                                                    "done": False,
                                                    "model_used": model_name
                                                }
                                    except Exception:
                                        continue

                    if accumulated_text:
                        is_fb = (model_name != models_to_try[0])
                        fb_reason = ""
                        if is_fb:
                            fb_reason = f"Mô hình {models_to_try[0]} từ Google tạm thời quá tải hoặc chạm hạn mức, KINI đã chuyển tiếp sang {model_name} để phản hồi liền mạch."

                        yield {
                            "done": True,
                            "full_text": accumulated_text,
                            "model_used": model_name,
                            "target_model": models_to_try[0],
                            "is_fallback": is_fb,
                            "fallback_reason": fb_reason,
                            "fallback_from_38": (model_mode in ["flash-3.8", "gemini-3.8-flash"] and model_name != "gemini-3.8-flash")
                        }
                        return
                else:
                    if res.status_code in (401, 403, 429):
                        continue
                    break
            except Exception:
                break

    # Fallback gọi không stream nếu mạng hoặc model gặp vấn đề
    fallback_res = ask_gemini(
        messages=messages,
        api_key=key,
        image_base64=image_base64,
        image_mime=image_mime,
        system_instruction=sys_inst,
        model_mode=model_mode,
        client_id=client_id,
        extra_images=extra_images
    )
    if fallback_res.get("success"):
        yield {
            "chunk": fallback_res.get("reply", ""),
            "done": False,
            "model_used": fallback_res.get("model_used", "gemini-3.1-flash-lite")
        }
        yield {
            "done": True,
            "full_text": fallback_res.get("reply", ""),
            "model_used": fallback_res.get("model_used", "gemini-3.1-flash-lite")
        }
    else:
        yield {
            "error": fallback_res.get("reply", "Lỗi phản hồi"),
            "done": True
        }
